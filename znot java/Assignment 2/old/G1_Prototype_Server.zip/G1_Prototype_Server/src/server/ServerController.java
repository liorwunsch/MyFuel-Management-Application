package server;

import java.io.IOException;

import gui.ServerWindowController;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class ServerController extends AbstractServer {

	final public static int DEFAULT_PORT = 5555;
	private Object lock;
	private ServerWindowController serverWindowController;
	private DatabaseController db;

	public ServerController(int port, Object lock, ServerWindowController serverWindowController) {
		super(port);
		this.lock = lock;
		db = new DatabaseController(serverWindowController);
		this.serverWindowController = serverWindowController;
	}

	// ServerController has instance of DatabaseController to interact with the db

	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		String message = (String) msg;
		serverWindowController.updateArea(message);
		try {
			// handle client's print request
			// request employee table as string from db
			// and send it back to the client
			if (message.equals("print employees"))
				client.sendToClient(db.printEmployees());

			// handle client's update request
			// request to update employee table from db
			// and send a message back to the client
			if (message.startsWith("update employee role")) {
				String[] words = message.split(" ");
				client.sendToClient(db.updateEmployeeRole(words[3], words[4]));
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
			serverWindowController.updateArea(e.getMessage());
		}
	}

	protected void serverStarted() {
		synchronized (lock) {
			System.out.println("Server listening for connections on port " + getPort());
			serverWindowController.updateArea("Server listening for connections on port " + getPort());
			lock.notifyAll();
		}
	}

	protected void serverStopped() {
		synchronized (lock) {
			System.out.println("Server has stopped listening for connections.");
			serverWindowController.updateArea("Server has stopped listening for connections.");
			lock.notifyAll();
		}
	}

	public void startListening() {
		try {
			this.listen(); // Start listening for connections
		} catch (Exception ex) {
			synchronized (lock) {
				System.out.println("ERROR - Could not listen for clients!");
				serverWindowController.updateArea("ERROR - Could not listen for clients!");
				lock.notifyAll();
			}
		}
	}

}