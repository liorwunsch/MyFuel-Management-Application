package guiClient;

public interface IFXML {
	public void callAfterMessage(String msg);

	public void openErrorAlert(String title, String msg);
}
