// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import java.io.IOException;

import entities.User;
import login.IFXML;
import ocsf.client.AbstractClient;

/**
 * This class overrides some of the methods defined in the abstract superclass
 * in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */

public class LogInChatClient extends AbstractClient {

	// Instance variables **********************************************

	/**
	 * The interface type variable. It allows the implementation of the display
	 * method in the client.
	 */
	ChatIF clientUI;
	public static User u1 = new User();
	public static boolean awaitResponse = false;
	private IFXML iFXMLController;
	public String lastMsg;

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @param clientUI The interface type variable.
	 */

	public LogInChatClient(String host, int port, ChatIF clientUI, Object iFXMLController) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		this.iFXMLController = (IFXML) iFXMLController;
	}

	// Instance methods ************************************************

	/**
	 * This method handles all data that comes in from the server.
	 *
	 * @param msg The message from the server.
	 */
	public void handleMessageFromServer(Object msg) {
		System.out.println("--> handleMessageFromServer");
		awaitResponse = false;
		String st;
		st = msg.toString();
		lastMsg = st;
		System.out.println(st);
//		String[] result = st.split(" ");
//		if (st.startsWith("login failed")) {
//			loginController.failedLogin();
//		}
//		if (st.startsWith("login success")) {
//			try {
//				if (result[2].equals("Marketing")) {
////				  loginController.successLogin(result[2]+" "+result[3]); 
//				} else {
////				  loginController.successLogin(result[2]); 
//				}
//
//			} catch (Exception e) {
//				System.out.println(e.getMessage());
//			}

//		}

	}

	/**
	 * This method handles all data coming from the UI
	 *
	 * @param message The message from the UI.
	 */

	public void handleMessageFromClientUI(String message) {

		try {
			openConnection();
			awaitResponse = true;
			sendToServer(message);
			// wait for response
			while (awaitResponse) {
				try {
					System.out.println("client waiting");
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			iFXMLController.callAfterMessage();
		} catch (IOException e) {
			e.printStackTrace();
			clientUI.display("Could not send message to server: Terminating client." + e);
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
//End of ChatClient class
