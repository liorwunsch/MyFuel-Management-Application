package login;

public interface IFXML {
	public void callAfterMessage();

}
