package login;

import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainLogin extends Application {

	public static void main(String args[]) throws Exception {
		launch(args);
	} // end main

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setResizable(false);
		Parent root = FXMLLoader.load(getClass().getResource("LoginWindow.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("LogIn");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
