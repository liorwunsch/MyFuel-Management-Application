import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.DatabaseMetaData;
import com.mysql.cj.jdbc.result.ResultSetMetaData;

public class TestDB {
	private Connection conn;

	public TestDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			System.out.println("Driver definition succeeded");
		} catch (Exception e) {
			System.out.println("Driver definition failed");
		}

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=IST", "root", "Aa123456");
			System.out.println("SQL connection succeeded\n");

		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("VendorError: " + e.getErrorCode());
		}
	}

	// add commentary *-*
	public String printEmployees() {
		StringBuilder b = new StringBuilder();
		DatabaseMetaData dbm;
		Statement stmt;
		try {

			dbm = (DatabaseMetaData) conn.getMetaData();
			ResultSet tables = dbm.getTables(null, null, "Employee", null);
			if (!tables.next())
				return "Employee table doesn't exist";

			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Employee");
			ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();

			boolean flag = false;
			while (rs.next()) {
				flag = true;
				for (int i = 1; i <= columnsNumber; i++)
					b.append(rs.getString(i) + "\t\t");
				b.append("\n");
			}
			rs.close();

			if (flag == false)
				return "Employee table empty";

		} catch (SQLException e) {
			e.printStackTrace();
			return "";
		}

		return b.toString();
	}

	public String updateEmployeeRole(String employee_id, String new_role) {
		PreparedStatement pStmt;
		Statement stmt;
		try {
			stmt = conn.createStatement();

			// check that employee_id exists in the database
			ResultSet rs = stmt.executeQuery("SELECT * FROM Employee WHERE employee_id=" + employee_id);
			if (!rs.next())
				return "employee_id not found";

			pStmt = conn.prepareStatement("UPDATE Employee " + "SET role = ? WHERE employee_id = ?");
			pStmt.setString(1, new_role);
			pStmt.setString(2, employee_id);
			pStmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return "updated employee role failed";
		}

		return "updated employee role succeeded";
	}

}
