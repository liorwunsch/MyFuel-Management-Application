package guiControllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class TestController {

	@FXML
	private TextField nameFieldText;

	@FXML
	private ComboBox<String> roleComboBox;

	@FXML
	private TableView<String> employeeDataTable;

	@FXML
	private Button updateBtn;

	@FXML
	private Button printBtn;

	@FXML
	void initialize() {
		roleComboBox.getItems().removeAll(roleComboBox.getItems());
		roleComboBox.getItems().addAll("Manager", "Assistant Manager", "Supplier");
	}

}
