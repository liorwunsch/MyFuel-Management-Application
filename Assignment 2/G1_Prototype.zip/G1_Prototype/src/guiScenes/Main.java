package guiScenes;

import guiControllers.TestController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Main extends Application {

	private static Stage mainStage;
	private static TestController control;

	@Override
	public void start(Stage primaryStage) {
		mainStage = primaryStage;
		try {
			// constructing our scene
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("Assigment2FXML.fxml"));
			AnchorPane anchorpane = (AnchorPane) loader.load();
			Scene scene = new Scene(anchorpane);
			control = (TestController) loader.getController();
			
			// setting the stage
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.setTitle("MyFuel Prototype");
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static TestController getControl() {
		return control;
	}

	public static Stage getMainStage() {
		return mainStage;
	}

	public static void main(String[] args) {
		launch(args);
	}

}
