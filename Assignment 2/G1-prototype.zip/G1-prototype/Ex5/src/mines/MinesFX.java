package mines;

import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

// uses fxml and mines.java as the structure for the scene
public class MinesFX extends Application {
	private Mines board;
	private int rows;
	private int cols;
	private MyController cler;

	@Override
	public void start(Stage primaryStage) {
		HBox hbox;

		// load fxml to hbox and save controller
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("check.fxml"));
			hbox = loader.load();
			cler = loader.getController();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		// add default minefield to stackpane
		StackPane stack = cler.getStackPane();
		stack.getChildren().add(makeGrid());

		// set action when pressing reset, delete old minefield
		// and add new minefield to stackpane, then resize the stage
		class ResetGrid implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent event) {
				stack.getChildren().clear();
				stack.getChildren().add(makeGrid());
				primaryStage.sizeToScene();
			}
		}
		cler.getReset().setOnAction(new ResetGrid());

		Scene s = new Scene(hbox);
		primaryStage.setTitle("The Amazing Mines Sweeper");
		primaryStage.setScene(s);
		primaryStage.show();
	}

	// making the minefield and returning it as a grid
	private GridPane makeGrid() {
		GridPane grid = new GridPane();
		rows = cler.getH();
		cols = cler.getW();
		board = new Mines(cler.getH(), cler.getW(), cler.getM());

		// for each button in the field set action when pressed
		class Open implements EventHandler<MouseEvent> {
			Button b;
			private int row;
			private int col;

			// constructor of nested class Open listener
			// save the caller button and its coordinates in the grid
			public Open(Button b, int row, int col) {
				super();
				this.b = b;
				this.row = row;
				this.col = col;
			}

			@Override
			public void handle(MouseEvent event) {
				// if pressed on button with rightclick, toggles flag if not open
				if (event.getButton() == MouseButton.SECONDARY) {
					board.toggleFlag(row, col);
					b.setText(board.get(row, col));
					return;
				}

				// if the button covers a mine, open all board
				boolean flag = board.open(row, col);
				if (flag == false)
					board.setShowAll(true);

				// after button is open and adjacencies too, check if the game is over
				// if it is, open new window and prompt for a win
				if (board.isDone() == true) {
					Stage stage2 = new Stage();
					Label label2 = new Label("Congratulations\nYou Won!");
					label2.setAlignment(Pos.CENTER);
					label2.setPadding(new Insets(10, 10, 10, 10));
					Scene scene2 = new Scene(label2);
					stage2.setScene(scene2);
					stage2.setWidth(200);
					stage2.show();
				}

				// update all buttons' titles
				for (Node g : grid.getChildren()) {
					int i = GridPane.getRowIndex(g);
					int j = GridPane.getColumnIndex(g);
					Button b = (Button) g;
					b.setText(board.get(i, j));
				}
			}
		}

		// load minefield game to the grid of buttons, all not open
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++) {
				String t = board.get(i, j);
				Button b = new Button(t);
				b.setFont(Font.font("Arial", FontWeight.BOLD, 20));
				b.setPrefSize(50, 50);
				b.setOnMouseClicked(new Open(b, i, j));
				grid.add(b, j, i);
			}

		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setAlignment(Pos.CENTER_LEFT);
		return grid;
	}

	public static void main(String[] args) {
		launch(args);
	}

}
