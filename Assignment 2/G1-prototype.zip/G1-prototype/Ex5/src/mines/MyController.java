package mines;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

// controller for minesweeper
public class MyController {
	@FXML
	private GridPane menu;

	@FXML
	private TextField width;

	@FXML
	private TextField height;

	@FXML
	private TextField mines;

	@FXML
	private Button reset;

	@FXML
	private StackPane stack;

	// return the stackpane where the minefield would be
	public StackPane getStackPane() {
		return stack;
	}

	// return the reset button for manipulation on action
	public Button getReset() {
		return reset;
	}

	// return height, width or mines read from the textfield
	// for manipulation when reset is pressed
	public int getH() {
		return Integer.parseInt(height.getCharacters().toString());
	}

	public int getW() {
		return Integer.parseInt(width.getCharacters().toString());
	}

	public int getM() {
		return Integer.parseInt(mines.getCharacters().toString());
	}
}
