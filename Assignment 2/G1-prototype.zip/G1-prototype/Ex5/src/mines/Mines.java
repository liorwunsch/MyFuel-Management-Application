package mines;

import java.util.Random;

// backend for the minesweeper game
public class Mines {
	private Integer field[][]; // a matrix for the open field with how many mines adjacent
	private String cover[][]; // a matrix for the covered field with a string
	private int rows;
	private int cols;
	private boolean showAll;

	// initialize mines with height, width and number of mines
	public Mines(int height, int width, int numMines) {
		// if number of mines exceeds field, fill the field with mines
		if (numMines > height * width)
			numMines = height * width;

		// initialize both matrixes and fill the field with 0 and the cover with '.'
		field = new Integer[height][width];
		cover = new String[height][width];
		for (int i = 0; i < height; i++)
			for (int j = 0; j < width; j++) {
				field[i][j] = 0;
				cover[i][j] = ".";
			}

		// save field's size
		rows = height;
		cols = width;
		showAll = false;

		// randomally choose places on the field and add mines to them
		// if add a mine did not succeed, don't count the add
		Random rand = new Random();
		for (int i = 0; i < numMines; i++) {
			if (addMine(rand.nextInt(rows), rand.nextInt(cols)) == false)
				i--;
		}
	}

	// add mine to place on field, if there's a mine there already
	// stop, else update all adjacent places
	public boolean addMine(int i, int j) {
		if (field[i][j] == -1)
			return false;

		field[i][j] = -1;

		add(i - 1, j);
		add(i + 1, j);
		add(i, j - 1);
		add(i, j + 1);
		add(i - 1, j - 1);
		add(i - 1, j + 1);
		add(i + 1, j - 1);
		add(i + 1, j + 1);
		return true;
	}

	// if place is within the greed and not a mine
	// count an adjacent mine's presence and updae it
	private boolean add(int i, int j) {
		if (i < 0 || i >= rows || j < 0 || j >= cols)
			return false;
		if (field[i][j] == -1)
			return false;

		field[i][j]++;
		return true;
	}

	// open a location on the field and open all adjacent
	// locations recursively if they are within the field
	// not mines, not already open, and don't have adjacent mines
	public boolean open(int i, int j) {
		if (i < 0 || i >= rows || j < 0 || j >= cols)
			return true;

		if (field[i][j] == -1)
			return false;

		if (cover[i][j].equals("open"))
			return true;
		cover[i][j] = "open";

		if (field[i][j] > 0)
			return true;

		open(i - 1, j);
		open(i + 1, j);
		open(i, j - 1);
		open(i, j + 1);
		open(i - 1, j - 1);
		open(i - 1, j + 1);
		open(i + 1, j - 1);
		open(i + 1, j + 1);
		return true;
	}

	// if place not open toggle between '.' and flag
	public void toggleFlag(int x, int y) {
		if (cover[x][y].equals("open"))
			return;

		if (cover[x][y].equals(".")) {
			cover[x][y] = "F";
			return;
		}
		if (cover[x][y].equals("F"))
			cover[x][y] = ".";
	}

	// check if all places that have no mines are open
	// if they are field is done
	public boolean isDone() {
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				if (field[i][j] != -1 && !(cover[i][j].equals("open")))
					return false;
		return true;
	}

	// get the character for the place in the field at the moment
	// return cover string only if grid is not all open
	// and this place is not open, if it's a mine return "X"
	// if there's no adjacent mine return " "
	// else return the number of adjacent mines
	public String get(int i, int j) {
		if (!(cover[i][j].equals("open")) && showAll == false)
			return cover[i][j];
		if (field[i][j] == -1)
			return "X";
		if (field[i][j] == 0)
			return " ";

		return field[i][j].toString();
	}

	// toggle showAll from input
	public void setShowAll(boolean showAll) {
		this.showAll = showAll;
	}

	// print the field with all locations
	// using get for open/not open/flagged
	public String toString() {
		StringBuilder b = new StringBuilder("");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++)
				b.append("" + get(i, j));
			b.append("\n");
		}
		return b.toString();
	}
}
