package iterator;

import java.util.Iterator;

// generalization of class TwoArrays for generics
public class Combined<E> implements Iterable<E> {
	private Iterator<E> f;
	private Iterator<E> s;

	// save iterators of both iterables
	public Combined(Iterable<E> first, Iterable<E> second) {
		f = first.iterator();
		s = second.iterator();
	}

	@Override
	public Iterator<E> iterator() {
		return new MyIterator();
	}

	private class MyIterator implements Iterator<E> {
		private int a = 1;

		// hasNext only if one of the iterables hasNext
		@Override
		public boolean hasNext() {
			return f.hasNext() || s.hasNext();
		}

		// print from first iterable and then from second
		// until no iterable hasNext, if one is done
		// print all that left in the other one
		@Override
		public E next() {
			if (a == 1) {
				a = 2;
				if (f.hasNext())
					return f.next();
				return s.next();
			}
			a = 1;
			if (s.hasNext())
				return s.next();
			return f.next();
		}
	}
}
