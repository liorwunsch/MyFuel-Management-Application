package iterator;

import java.util.Iterator;

// a class for iterating through 2 integer arrays
public class TwoArrays implements Iterable<Integer> {
	private int a1[];
	private int a2[];

	// save both arrays;
	public TwoArrays(int[] a1, int[] a2) {
		this.a1 = a1;
		this.a2 = a2;
	}

	@Override
	public Iterator<Integer> iterator() {
		return new MyIterator();
	}

	// iterate through both arrays, one from first, one from second
	// until they have no numbers left to print, if one is done
	// print all that left in the other one
	private class MyIterator implements Iterator<Integer> {
		private int cur = -1;
		private int a = 1;

		@Override
		public boolean hasNext() {
			return (cur + 1) < a1.length || cur < a2.length;
		}

		@Override
		public Integer next() {
			if (a == 1) {
				if ((cur + 1) < a1.length) {
					a = 2;
					return a1[++cur];
				}
				if ((cur + 1) == a1.length)
					cur++;
				return a2[cur++];
			}
			if (cur < a2.length) {
				a = 1;
				return a2[cur];
			}
			return a1[++cur];
		}
	}
}
