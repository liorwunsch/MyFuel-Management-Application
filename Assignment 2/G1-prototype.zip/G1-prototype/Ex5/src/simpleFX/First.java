package simpleFX;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

// implementation of voting machine about ofra haza and yardena arazi
public class First extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	// scene is generally a vbox with all nodes in it and a title
	@Override
	public void start(Stage stage) {
		Scene scene = new Scene(makeVBox());
		stage.setTitle("Voting Machine");
		stage.setScene(scene);
		stage.show();
	}

	// used for the value made from the votes
	private int i;

	public VBox makeVBox() {
		// initialize a vbox with spacing, 2 buttons and a label
		VBox root = new VBox(20);
		Button o = makeButton("Ofra Haza");
		Button y = makeButton("Yardena Arazi");
		Label label = makeLabel();

		// listener will be attached to ofra's button o, and increase i each press
		class LabelIncreaser implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent event) {
				i++;
				label.setText(i + "");
			}
		}

		// listener will be attached to yardena's button y, and decrease i each press
		class LabelDecreaser implements EventHandler<ActionEvent> {
			@Override
			public void handle(ActionEvent event) {
				i--;
				label.setText(i + "");
			}
		}

		o.setOnAction(new LabelIncreaser());
		y.setOnAction(new LabelDecreaser());

		// use a gridpane with horizontal spacing and 2 buttons o and y
		GridPane grid = new GridPane();
		grid.setHgap(20);
		grid.add(o, 0, 1);
		grid.add(y, 1, 1);
		// make the buttons stick to the top left of the scene and add padding
		grid.setPadding(new Insets(20, 10, 0, 10));
		grid.setAlignment(Pos.TOP_LEFT);

		// use a stackpane for the label showing votes' value
		StackPane stack = new StackPane(label);
		stack.setPadding(new Insets(0, 10, 10, 10));

		// add nodes to vbox and return it
		root.getChildren().addAll(grid, stack);
		return root;
	}

	// make a label for votes' value, add background color and make it stretchable to screen
	private Label makeLabel() {
		BackgroundFill bgFill = new BackgroundFill(Color.AQUA, null, null);
		Background bg = new Background(bgFill);

		Label counter = new Label("0");	// value starts as 0
		counter.setBackground(bg);
		counter.setPrefHeight(40);
		counter.setMaxWidth(Double.MAX_VALUE);
		counter.setAlignment(Pos.CENTER); // keep value in center of label
		return counter;
	}

	// make a button with title msg and set its font and return it
	private Button makeButton(String msg) {
		Button b = new Button(msg);
		b.setFont(new Font("Arial", 12));
		return b;
	}
}