package simpleFX2;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// implementation of voting machine with scene builder
public class Second extends Application {

	@Override
	public void start(Stage primaryStage) {
		VBox vbox;
		
		// load fxml built like simpleFX:First to vbox and controller
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("check.fxml"));
			vbox = loader.load();
			loader.getController();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		
		// add loaded screen to scene and add title
		Scene s = new Scene(vbox);
		primaryStage.setTitle("Voting Machine");
		primaryStage.setScene(s);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}