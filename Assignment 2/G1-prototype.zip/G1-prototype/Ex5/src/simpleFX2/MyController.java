package simpleFX2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

// controller for second's fxml
public class MyController {
	private int i = 0; // votes' value

	@FXML
	private VBox root;

	@FXML
	private GridPane grid;

	@FXML
	private Button o;

	@FXML
	private Button y;

	@FXML
	private StackPane stack;

	@FXML
	private Label label;

	@FXML
	void pressO(ActionEvent event) {
		i++;
		label.setText(i + "");
	}
	// action on pressing ofra's button is increasing i and updating label

	@FXML
	void pressY(ActionEvent event) {
		i--;
		label.setText(i + "");
	}
	// action on pressing yardena's button is decreasing i and updating label

}