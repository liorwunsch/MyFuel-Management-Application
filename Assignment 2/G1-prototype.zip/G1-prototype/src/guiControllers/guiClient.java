package guiControllers;

//This file contains material supporting section 3.7 of the textbook:

//"Object Oriented Software Engineering" and is issued under the open-source
//license found at www.lloseng.com 

import ocsf.client.*;

import common.*;
import guiControllers.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
//import javafx.scene.control.Label;
import javafx.scene.control.TableView;

import java.io.*;

/**
 * This class overrides some of the methods defined in the abstract superclass
 * in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */
public class guiClient extends AbstractClient {
	// Instance variables **********************************************

	/**
	 * The interface type variable. It allows the implementation of the display
	 * method in the client.
	 */
	ChatIF clientUI;
	Object lock;
	private String lastMsg = "banana";

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @param clientUI The interface type variable.
	 */

	public guiClient(String host, int port, ChatIF clientUI, Object lock) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		this.lock = lock;
		openConnection();
	}

	// Instance methods ************************************************

	/**
	 * This method handles all data that comes in from the server.
	 *
	 * @param msg The message from the server.
	 */
	public void handleMessageFromServer(Object msg) {

		synchronized (lock) {
			String str = (String) msg;
			lastMsg = str;
			clientUI.display(msg.toString());
			lock.notifyAll();
		}
//		ObservableList<Employee> list = FXCollections.observableArrayList();
//		for (int i = 0; i < employeeDataTable.getItems().size(); i++) {
//			employeeDataTable.getItems().clear();
//		}
//		if (str.startsWith("success")) {
//			employeeDataTable.setVisible(true);
//			String[] strArr = str.split("\t\t");
//			for (int i = 1; i < strArr.length; i = i + 6) {
//				Employee emp = new Employee(strArr[i], strArr[i + 1], strArr[i + 2], strArr[i + 3], strArr[i + 4],
//						strArr[i + 5]);
//				list.add(emp);
//			}
//			employeeDataTable.setItems(list);
//		}
//
//		else {
//			employeeDataTable.setVisible(false);
//			a.setContentText(str);
//			try {
////				a.show();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//
//		}
	}

	public String getLastMsg() {
		return lastMsg;
	}

	/**
	 * This method handles all data coming from the UI
	 *
	 * @param message The message from the UI.
	 */
	public void handleMessageFromClientUI(String message) {
		try {
			sendToServer(message);
		} catch (IOException e) {
			clientUI.display("Could not send message to server.  Terminating client.");
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
//End of ChatClient class
