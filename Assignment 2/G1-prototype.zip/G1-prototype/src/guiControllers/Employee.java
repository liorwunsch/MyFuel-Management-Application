package guiControllers;

public class Employee {
	private String employeeID;
	private String firstname;
	private String surname;
	private String email;
	private String role;
	private String association;

	public Employee(String employeeID,String firstname,String surname,String email,String role,String association) {
	        this.setEmployeeID(employeeID);
	        this.setFirstname(firstname);
	        this.surname = surname;
	        this.setEmail(email);
	        this.setRole(role);
	        this.setAssociation(association);
	    }

	public String getSurname() {
		return surname;
	}

	public String getAssociation() {
		return association;
	}

	public void setAssociation(String association) {
		this.association = association;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
}
