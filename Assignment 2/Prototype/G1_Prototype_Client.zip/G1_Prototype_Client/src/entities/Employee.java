package entities;

public class Employee {
	private String employeeID;
	private String firstName;
	private String surname;
	private String email;
	private String role;
	private String affiliation;

	public Employee(String employeeID, String firstname, String surname, String email, String role,
			String affiliation) {
		this.setEmployeeID(employeeID);
		this.setFirstName(firstname);
		this.surname = surname;
		this.setEmail(email);
		this.setRole(role);
		this.setAffiliation(affiliation);
	}

	public String getSurname() {
		return surname;
	}

	public String getAffiliation() {
		return affiliation;
	}

	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstname) {
		this.firstName = firstname;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
}
