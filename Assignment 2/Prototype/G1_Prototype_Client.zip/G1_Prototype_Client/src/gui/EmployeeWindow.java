package gui;

import java.io.IOException;

//import java.lang.reflect.Method;
//
//import com.sun.javafx.scene.control.skin.NestedTableColumnHeader;
//import com.sun.javafx.scene.control.skin.TableColumnHeader;
//import com.sun.javafx.scene.control.skin.TableHeaderRow;
//import com.sun.javafx.scene.control.skin.TableViewSkin;

//import client.ChatClient;
import client.ClientConsole;
import client.EmployeeController;
import entities.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
//import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class EmployeeWindow {

	@FXML
	private TextField employeeIDTextField;

	@FXML
	private ComboBox<String> roleComboBox;

	@FXML
	private TableView<Employee> employeeDataTable;

	@FXML
	private Button updateBtn;

	@FXML
	private TextField errorTextField;

	@FXML
	private Button printBtn;
	private EmployeeController client;
	Object lock = new Object();
	Alert a = new Alert(AlertType.ERROR);

	@FXML
	void initialize() throws IOException {
		roleComboBox.getItems().removeAll(roleComboBox.getItems());
		roleComboBox.getItems().addAll("Manager", "Assistant Manager", "Supplier");
		employeeDataTable.setMaxWidth(Double.MAX_VALUE);
		employeeDataTable.setMaxHeight(Double.MAX_VALUE);

		TableColumn<Employee, String> idColumn = new TableColumn<Employee, String>("Employee ID");
		idColumn.setCellValueFactory(new PropertyValueFactory<>("employeeID"));
//		idColumn.setResizable(true);
		employeeDataTable.getColumns().add(idColumn);

		TableColumn<Employee, String> firstnameColumn = new TableColumn<Employee, String>("First Name");
		firstnameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
//		firstnameColumn.setResizable(true);
		employeeDataTable.getColumns().add(firstnameColumn);

		TableColumn<Employee, String> surnameColumn = new TableColumn<Employee, String>("Surname");
		surnameColumn.setCellValueFactory(new PropertyValueFactory<>("surname"));
//		surnameColumn.setResizable(true);
		employeeDataTable.getColumns().add(surnameColumn);

		TableColumn<Employee, String> emailColumn = new TableColumn<Employee, String>("Email");
		emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
		employeeDataTable.getColumns().add(emailColumn);

		TableColumn<Employee, String> roleColumn = new TableColumn<Employee, String>("Role");
		roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
//		roleColumn.setResizable(true);
		employeeDataTable.getColumns().add(roleColumn);

		TableColumn<Employee, String> associationColumn = new TableColumn<Employee, String>("Affiliation");
		associationColumn.setCellValueFactory(new PropertyValueFactory<>("affiliation"));
//		associationColumn.setResizable(true);
		employeeDataTable.getColumns().add(associationColumn);

//		employeeDataTable.getColumns().addAll(idColumn, firstnameColumn,surnameColumn,emailColumn,roleColumn,associationColumn);
		a.setContentText("banana");
		client = new EmployeeController("localhost", 5555, new ClientConsole("localhost", 5555),lock);
	}

	public void printBtnPressed() throws IOException, InterruptedException {
		client.sendToServer("print employees");
		synchronized(lock) {
			try {
				lock.wait();
			} catch (InterruptedException e) {
			}
		}
		updateTableView();
	}

	public void updateBtnPressed() throws IOException, InterruptedException {

		if (employeeIDTextField.getText().equals("") || roleComboBox.getSelectionModel().isEmpty()) {
			a.setContentText("Please enter data into field and combobox");
			a.show();
		} else {
			String msg = "update employee role";
			msg += " " + employeeIDTextField.getText();
			msg += " " + roleComboBox.getSelectionModel().getSelectedItem();
			client.sendToServer(msg);
			synchronized(lock) {
				try {
					lock.wait();
				} catch (InterruptedException e) {
				}
			}
			updateTableView();
		}

	}

	private void updateTableView() {
		String str = client.getLastMsg();
		ObservableList<Employee> list = FXCollections.observableArrayList();
		
		if (str.startsWith("success")) {
			for (int i = 0; i < employeeDataTable.getItems().size(); i++) {
				employeeDataTable.getItems().clear();
			}
			employeeDataTable.setVisible(true);
			String[] strArr = str.split("\t\t");
			for (int i = 1; i < strArr.length; i = i + 6) {
				Employee emp = new Employee(strArr[i], strArr[i + 1], strArr[i + 2], strArr[i + 3], strArr[i + 4],
						strArr[i + 5]);
				list.add(emp);
			}
			employeeDataTable.setItems(list);
		}

		else {
			a.setContentText(str);
			a.show();
		}
	}
}
