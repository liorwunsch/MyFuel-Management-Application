package loginwindow;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class LoginFXControl {

	@FXML
	private VBox vbox1;

	@FXML
	private TextField entry_username;

	@FXML
	private PasswordField entry_password;

	@FXML
	private Button btn_signin;

}
